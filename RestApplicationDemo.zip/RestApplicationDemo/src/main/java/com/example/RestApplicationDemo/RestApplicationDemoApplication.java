package com.example.RestApplicationDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApplicationDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApplicationDemoApplication.class, args);
	}
}

